$2 >labview-moc.stdout.test &
$3 >qt-moc.stdout.test

diff labview-moc.stdout.test "$1/"labview-moc.stdout && diff qt-moc.stdout.test "$1/"qt-moc.stdout
