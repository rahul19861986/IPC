#include "StreamIPC.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int fibmod100(int n) {
  int t1 = 0;
  int t2 = 1;
  for (int i = 0; i < n; i++) {
    int next = t1 + t2;
    t1 = t2 % 100;
    t2 = next % 100;
  }
  return t1;
}

double data[10] = {0};

void update_data(int n) {
  for (int i = 0; i < 10; i++) {
    data[i] = fibmod100(n + i);
  }
}

int main() {
  labviewInit();

  bool exit_program = false;
  char *msg;
  while (true) {
    msg = getMessage();
    printf("received msg: %s\n", msg);
    if (strcmp(msg, "Exit") == 0) {
      printf("exitting program\n");
      break;
    } else {
      int stream_id = 0;
      sscanf(msg, "Send Stream %d", &stream_id);
      printf("sending stream: %d\n", stream_id);
      update_data(stream_id);
      sendStream(stream_id, "today", .1, data, 10);
    }
  }

  labviewDestroy();
}
