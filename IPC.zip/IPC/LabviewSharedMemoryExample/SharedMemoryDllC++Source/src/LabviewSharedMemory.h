#include "extcode.h"
#include "cvilvsb.h"
#include "fundtypes.h"
#include "hosttype.h"
#include "platdefines.h"
#include <windows.h>
#include <fcntl.h>
#include <sys/types.h>
#include <stdio.h>
#include <process.h>
#include <memory.h>


extern "C"{
	_declspec(dllexport) DWORD SharedMemoryCreate(void);
	_declspec(dllexport) DWORD SharedMemoryRead(float *x1[]);
	_declspec(dllexport) DWORD SharedMemoryWrite(float *y1[]);
	_declspec(dllexport) DWORD SharedMemoryClose(void);
}